# Kariera: Od B-klasy — wersja mobilna

Ta wersja jest przygotowana pod telefon:
- duże przyciski dotykowe,
- układ portrait,
- interfejs mobile-first,
- możliwość instalacji jako PWA,
- podstawowy tryb offline przez Service Worker.

## Jak uruchomić na iPhone
PWA musi być uruchomiona z HTTPS (np. przez hosting). Sam plik `index.html` z aplikacji Pliki nie wystarczy do pełnej instalacji.

Najprościej wrzucić folder na dowolny hosting statyczny obsługujący HTTPS, np. GitHub Pages, Netlify lub Vercel. Potem otworzyć adres w Safari i wybrać:
Udostępnij → Dodaj do ekranu początkowego.

## Następny etap
Dodanie prawdziwej bazy klubów, tabel ligowych, terminarza, transferów, kontraktów, ofert i symulacji całych lig.
